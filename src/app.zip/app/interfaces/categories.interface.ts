export interface Categories {
    _id: string;
    name: string;
    items: number;
}