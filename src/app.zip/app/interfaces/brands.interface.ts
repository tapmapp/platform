export interface Brands {
    _id: string;
    name: string;
}