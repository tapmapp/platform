export interface Stores {
    _id: string;
    name: string;
    address: string;
    postalCode: string;
    country: string;
    phone: string;
    lat: string;
    long: string;
}