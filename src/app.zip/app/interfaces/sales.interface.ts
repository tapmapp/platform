export interface Sales {
    id: number;
    category: string;
    items: number;
}