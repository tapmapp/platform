export interface FindedProducts {
    _id: number;
    name: string;
    brand: string;
    brandName: string;
    img: string;
}