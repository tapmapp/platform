export interface ClientsLists {
    _id: string;
    name: string;
    number: Number;
    users: Array<string>;
    active: boolean;
}