export * from './mobile.component';
