export * from './stores.component';
