export * from './campaign-info.component';
