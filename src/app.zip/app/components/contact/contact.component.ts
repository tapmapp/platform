import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'contact',
  providers: [ ],
  styleUrls: ['./contact.component.css'],
  templateUrl: './contact.component.html'
})
export class ContactComponent implements OnInit {

  constructor() {}

  ngOnInit() {}

}
