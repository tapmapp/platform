import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'header-comp',
  providers: [],
  styleUrls: [ './header.component.css' ],
  templateUrl: './header.component.html'
})
export class HeaderComponent {

  constructor() {}


}
