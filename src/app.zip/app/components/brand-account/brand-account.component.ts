import { Component, OnInit } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Component({
  selector: 'brand-account',
  providers: [],
  styleUrls: [ './brand-account.component.css' ],
  templateUrl: './brand-account.component.html'
})
export class BrandAccountComponent implements OnInit {

  constructor() {}

  ngOnInit() {}

}
