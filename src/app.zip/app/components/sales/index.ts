export * from './sales.component';
