export * from './cashier.component';
