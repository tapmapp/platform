export * from './footer.component';
