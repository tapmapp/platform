import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'footer-comp',
  providers: [],
  styleUrls: [ './footer.component.css' ],
  templateUrl: './footer.component.html'
})
export class FooterComponent {

  constructor() {}

}
