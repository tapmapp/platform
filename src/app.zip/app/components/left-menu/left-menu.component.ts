import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'left-menu',
  providers: [],
  styleUrls: [ './left-menu.component.css' ],
  templateUrl: './left-menu.component.html'
})
export class LeftMenuComponent {

  constructor() {}

}
