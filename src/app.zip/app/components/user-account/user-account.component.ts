import { Component, OnInit } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Component({
  selector: 'user-account',
  providers: [],
  styleUrls: [ './user-account.component.css' ],
  templateUrl: './user-account.component.html'
})
export class UserAccountComponent implements OnInit {

  constructor() {}

  ngOnInit() {}

}
