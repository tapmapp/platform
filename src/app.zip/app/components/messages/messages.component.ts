import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'messages',
  providers: [ ],
  styleUrls: ['./messages.component.css'],
  templateUrl: './messages.component.html'
})
export class MessagesComponent implements OnInit {

  constructor() {}

  ngOnInit() {}

}
