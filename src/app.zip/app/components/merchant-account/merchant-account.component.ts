import { Component, OnInit } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Component({
  selector: 'merchant-account',
  providers: [],
  styleUrls: [ './merchant-account.component.css' ],
  templateUrl: './merchant-account.component.html'
})
export class MerchantAccountComponent implements OnInit {

  constructor() {}

  ngOnInit() {}

}
