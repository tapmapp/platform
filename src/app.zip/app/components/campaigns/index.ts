export * from './campaigns.component';
